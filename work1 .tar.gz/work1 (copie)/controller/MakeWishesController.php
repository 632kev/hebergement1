<?php

if(isset($_POST['submit'])){

    $name=$_POST['name'];
    $descript=$_POST['descript'];
    $reason=$_POST['reason'];
    $date=new DateTime();
    $createdAt=$date->format("y-m-d h-i-s");
    
    require_once("../model/makeWishesModel.php");
    saveWish($name,$descript,$reason,$createdAt);
    header("location:../views/login.php");
    
}
require_once("../views/makeWishes.php");

?>