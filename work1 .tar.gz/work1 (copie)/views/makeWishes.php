<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet", href="../assets/style.css">
    <title>WISHES MAKER</title>
</head>
<body>
    <fieldset id="fieldset">MAKE YOUR WISH</fieldset> <br>
        
        <div class="grid-container">

            <form method="POST">
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" placeholder="Enter your name">  <br><br>
                <label for="descript">Describe your wish:</label><br>
                <textarea name="descript" cols="30" rows="10" placeholder=""></textarea><br>
                <label for="reason">Reason:</label><br>
                <textarea name="reason" cols="30" rows="10" placeholder=""></textarea><br><br>
                <input type="submit" name="submit" id="submit" value="MAKE A WISH"><br><br>
            </form>
        </div>
    
</body>
</html>