<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet", href="../assets/style.css">

</head>
<body>
    <fieldset id="fieldset">MAKE YOUR WISH</fieldset> <br><br>

    <div class="grid-container">
        <h1>YOUR WISHE IS MAKED</h1> <br>
        <h1>Click here to make another wish</h1>
        <div class="arrow"></div>
        <button id="submit"><a href="../controller/MakeWishesController.php">MAKE ANOTHER WISH</a></button>
    </div>

</body>
</html>