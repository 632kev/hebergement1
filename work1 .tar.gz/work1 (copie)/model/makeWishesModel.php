<?php

require_once("../model/db.config.php");

function saveWish($name,$descript,$reason,$createdAt){
    $db=_connect();
    $_request=$db-> prepare ("INSERT INTO wishes(name,descript,reason,createdAt)values(?,?,?,?)");
    $_request->execute ([$name,$descript,$reason,$createdAt]);

}
?>