<?php

function _connect(){
    return new PDO("mysql:host=localhost;dbname=xxdb","shadow","hunter");

}
?>